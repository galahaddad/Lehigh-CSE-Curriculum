Homework Assignment 2, Korth CSE 341
Ralph Haddad

This zipped folder contains the Part1.txt file with the sql commands and the Part 2 fully robust.

Cheers :)